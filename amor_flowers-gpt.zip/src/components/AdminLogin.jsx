import { useState } from "react";
import { useAdminStore } from "../store/admin.js";

function AdminLogin() {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const login = useAdminStore((s) => s.login);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (login(pw)) setErr("");
    else setErr("Неверный пароль!");
  };

  return (
    <form onSubmit={handleSubmit} className="mx-auto w-full max-w-sm bg-white/80 rounded-xl shadow p-8 flex flex-col gap-4">
      <input
        type="password"
        placeholder="Пароль администратора"
        value={pw}
        onChange={(e) => setPw(e.target.value)}
        className="border rounded px-4 py-2 outline-amor-accent"
        autoFocus
      />
      <button type="submit" className="bg-amor-accent text-white font-bold px-6 py-2 rounded-lg hover:bg-amor-dark transition">Войти</button>
      {err && <div className="text-red-500 text-sm">{err}</div>}
    </form>
  );
}

export default AdminLogin;
