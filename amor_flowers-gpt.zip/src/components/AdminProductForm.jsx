import React, { useState } from "react";
import COLORS from "../data/colors";
import OCCASIONS from "../data/occasions";
import FLOWER_TYPES from "../data/flowers";
import "./Admin.css";

// Группы для поводов
const OCCASION_GROUPS = [
  {
    label: "Семейные и личные",
    items: [
      "День рождения", "Юбилей", "Годовщина", "Свадьба", "Помолвка", "Выписка из роддома",
      "День Святого Валентина", "Любовь и романтика", "День Матери", "День Отца",
      "Для мамы", "Для папы", "Для жены", "Для мужа", "Для дочки", "Для сына", "Для сестры", "Для брата",
      "Для любимой", "Для девушки", "Для подруги", "Для друга", "Для бабушки", "Для дедушки"
    ].filter(o => OCCASIONS.includes(o))
  },
  {
    label: "Профессиональные и учебные",
    items: [
      "1 сентября", "День знаний", "День учителя", "Последний звонок", "Выпускной",
      "Для учителя", "Для воспитателя", "Для классного руководителя", "Для коллеги", "Для начальника"
    ].filter(o => OCCASIONS.includes(o))
  },
  {
    label: "Праздничные",
    items: [
      "8 Марта", "23 Февраля", "Новый год", "Рождество", "Пасха", "День влюбленных", "День семьи"
    ].filter(o => OCCASIONS.includes(o))
  },
  {
    label: "Без повода и особое",
    items: [
      "Без повода", "Просто так", "Для хорошего настроения", "Извинения", "Спасибо", "Приятный сюрприз"
    ].filter(o => OCCASIONS.includes(o))
  },
  {
    label: "Остальное",
    items: OCCASIONS.filter(o =>
      ![
        ...(
          "День рождения,Юбилей,Годовщина,Свадьба,Помолвка,Выписка из роддома,День Святого Валентина,Любовь и романтика,День Матери,День Отца,Для мамы,Для папы,Для жены,Для мужа,Для дочки,Для сына,Для сестры,Для брата,Для любимой,Для девушки,Для подруги,Для друга,Для бабушки,Для дедушки," +
          "1 сентября,День знаний,День учителя,Последний звонок,Выпускной,Для учителя,Для воспитателя,Для классного руководителя,Для коллеги,Для начальника," +
          "8 Марта,23 Февраля,Новый год,Рождество,Пасха,День влюбленных,День семьи," +
          "Без повода,Просто так,Для хорошего настроения,Извинения,Спасибо,Приятный сюрприз"
        ).split(",")
      ]
        .includes(o)
    )
  }
];

export default function AdminProductForm({ onSubmit, initial = {}, submitLabel = "Добавить" }) {
  const [title, setTitle] = useState(initial.title || "");
  const [price, setPrice] = useState(initial.price || "");
  const [colors, setColors] = useState(initial.colors || []);
  const [occasions, setOccasions] = useState(initial.occasions || []);
  const [types, setTypes] = useState(initial.types || []);
  const [image, setImage] = useState(initial.image || "");

  function toggle(val, arr, setArr) {
    setArr(arr.includes(val) ? arr.filter(v => v !== val) : [...arr, val]);
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!title || !price) return alert("Заполните название и цену");
    onSubmit({ title, price, colors, occasions, types, image });
    if (!initial.title) { // если это создание, а не редактирование — чистим
      setTitle(""); setPrice(""); setColors([]); setOccasions([]); setTypes([]); setImage("");
    }
  }

  return (
    <form className="admin-form" onSubmit={handleSubmit} autoComplete="off">
      <div className="form-row">
        <label>Название:</label>
        <input
          type="text"
          value={title}
          onChange={e => setTitle(e.target.value)}
          required
          autoFocus
        />
      </div>
      <div className="form-row">
        <label>Цена:</label>
        <input
          type="number"
          value={price}
          min="0"
          onChange={e => setPrice(e.target.value)}
          required
        />
      </div>
      <div className="form-row">
        <label>Цвета:</label>
        <div className="checkbox-list">
          {COLORS.map((c) => (
            <label key={c.name} className="checkbox-item">
              <input
                type="checkbox"
                checked={colors.includes(c.name)}
                onChange={() => toggle(c.name, colors, setColors)}
              />
              <span className="color-dot" style={{ background: c.code }} />
              {c.name}
            </label>
          ))}
        </div>
      </div>
      <div className="form-row">
        <label>Поводы:</label>
        <div className="occasion-groups">
          {OCCASION_GROUPS.map((group) => (
            <div key={group.label} className="occasion-group">
              <div className="occasion-group-title">{group.label}</div>
              <div className="checkbox-list">
                {group.items.map(o => (
                  <label key={o} className="checkbox-item">
                    <input
                      type="checkbox"
                      checked={occasions.includes(o)}
                      onChange={() => toggle(o, occasions, setOccasions)}
                    />
                    {o}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="form-row">
        <label>Типы цветов:</label>
        <div className="checkbox-list">
          {FLOWER_TYPES.map((t) => (
            <label key={t} className="checkbox-item">
              <input
                type="checkbox"
                checked={types.includes(t)}
                onChange={() => toggle(t, types, setTypes)}
              />
              {t}
            </label>
          ))}
        </div>
      </div>
      <div className="form-row">
        <label>Ссылка на изображение:</label>
        <input
          type="text"
          value={image}
          onChange={e => setImage(e.target.value)}
        />
      </div>
      <div className="form-actions">
        <button type="submit" className="admin-btn">{submitLabel}</button>
      </div>
    </form>
  );
}
