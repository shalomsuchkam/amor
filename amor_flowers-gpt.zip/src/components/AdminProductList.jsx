import React from "react";
import "./Admin.css";

export default function AdminProductList({ products, onEdit, onDelete }) {
  return (
    <table className="admin-table">
      <thead>
        <tr>
          <th>Название</th>
          <th>Цена</th>
          <th>Цвета</th>
          <th>Поводы</th>
          <th>Типы</th>
          <th>Фото</th>
          <th>Действия</th>
        </tr>
      </thead>
      <tbody>
        {products.length === 0 && (
          <tr>
            <td colSpan={7} style={{ textAlign: "center", color: "#aaa", padding: "26px 0" }}>
              Букеты не найдены
            </td>
          </tr>
        )}
        {products.map((product) => (
          <tr key={product.id}>
            <td>{product.title}</td>
            <td>{product.price}</td>
            <td>
              {(product.colors || []).map(c => <span key={c} className="mini-chip">{c}</span>)}
            </td>
            <td>
              {(product.occasions || []).map(o => <span key={o} className="mini-chip">{o}</span>)}
            </td>
            <td>
              {(product.types || []).map(t => <span key={t} className="mini-chip">{t}</span>)}
            </td>
            <td>
              {product.image && <img src={product.image} alt="" style={{ maxWidth: 60, maxHeight: 40, borderRadius: 3 }} />}
            </td>
            <td className="admin-table-actions">
              <button className="admin-btn" onClick={() => onEdit(product)}>Редактировать</button>
              <button className="admin-btn" style={{ background: "#eee", color: "#a23", border: "1px solid #eed" }} onClick={() => onDelete(product.id)}>Удалить</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
