import { useState, useRef, useEffect } from "react";
import OCCASIONS from "../data/occasions.js";
// Можно использовать lucide-react или любой SVG для стрелки
// import { ChevronDown } from "lucide-react";

function OccasionDropdown({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef();

  useEffect(() => {
    function handleClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  // Фильтрация
  const filtered = search
    ? OCCASIONS.filter(o => o.toLowerCase().includes(search.toLowerCase()))
    : OCCASIONS.slice(0, 30);

  function handleSelect(oc) {
    onChange(oc);
    setOpen(false);
    setSearch("");
  }

  return (
    <div className="relative w-full md:w-52" ref={ref}>
      <button
        type="button"
        className={`w-full px-4 py-2 bg-white rounded-xl border outline-amor-accent text-lg flex items-center justify-between transition-all
          ${open ? "ring-2 ring-amor-accent border-amor-accent" : ""}
        `}
        onClick={() => setOpen(v => !v)}
      >
        <span className={`truncate ${!value && "text-gray-400"}`}>
          {value || "Все поводы"}
        </span>
        <span className={`ml-2 transition ${open ? "rotate-180" : ""}`} style={{lineHeight: 0}}>
          {/* SVG-стрелка */}
          <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M6 9l6 6 6-6"/>
          </svg>
        </span>
      </button>
      {open && (
        <div className="absolute z-30 left-0 mt-2 w-full bg-white rounded-2xl shadow-xl border p-2 max-h-64 overflow-y-auto animate-fade-in-up">
          <input
            autoFocus
            type="text"
            className="w-full px-3 py-2 mb-2 rounded-lg border outline-amor-accent text-base bg-gray-50"
            placeholder="Быстрый поиск..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            onClick={e => e.stopPropagation()}
          />
          <ul>
            {/* ВСЕ ПОВОДЫ - всегда первой строкой */}
            <li>
              <button
                type="button"
                className={`w-full text-left px-3 py-2 rounded-lg mb-1 ${
                  !value
                    ? "bg-amor-accent text-white"
                    : "hover:bg-amor-accent/10 text-amor-accent"
                } transition`}
                onClick={() => handleSelect("")}
              >
                Все поводы
              </button>
            </li>
            {filtered.map((oc, i) => (
              <li key={i}>
                <button
                  type="button"
                  className={`w-full text-left px-3 py-2 rounded-lg mb-1 ${
                    value === oc
                      ? "bg-amor-accent text-white"
                      : "hover:bg-amor-accent/10 text-amor-accent"
                  } transition`}
                  onClick={() => handleSelect(oc)}
                >
                  {oc}
                </button>
              </li>
            ))}
          </ul>
          {filtered.length === 0 && (
            <div className="text-gray-400 text-sm text-center py-6">Нет совпадений</div>
          )}
        </div>
      )}
    </div>
  );
}

export default OccasionDropdown;
