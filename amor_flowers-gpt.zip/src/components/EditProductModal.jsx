import React from "react";
import "./Admin.css";

export default function EditProductModal({ open, product, onSave, onClose }) {
  if (!open) return null;
  return (
    <div className="modal-overlay">
      <div className="modal-window">
        <button className="modal-close" onClick={onClose}>×</button>
        <h2 style={{ marginBottom: 15, fontSize: "1.15rem" }}>Редактировать букет</h2>
        <AdminProductForm
          initial={product}
          submitLabel="Сохранить"
          onSubmit={onSave}
        />
      </div>
    </div>
  );
}
