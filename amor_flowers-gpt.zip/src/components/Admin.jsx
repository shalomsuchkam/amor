console.log("Admin loaded!");
import React, { useState, useEffect } from "react";
import { supabase } from "../supabaseClient";
import AdminProductForm from "./AdminProductForm";
import AdminProductList from "./AdminProductList";
import EditProductModal from "./EditProductModal";
import "./Admin.css";

export default function Admin() {
  const [products, setProducts] = useState([]);
  const [editProduct, setEditProduct] = useState(null);

  useEffect(() => {
    supabase.from("products").select("*").then(({ data }) => setProducts(data || []));
  }, []);

  async function handleAdd(product) {
    const { data } = await supabase.from("products").insert([product]).select("*");
    if (data) setProducts([...products, ...data]);
  }

  async function handleEditSave(updated) {
    await supabase.from("products").update(updated).eq("id", editProduct.id);
    setProducts(products.map(p => p.id === editProduct.id ? { ...p, ...updated } : p));
    setEditProduct(null);
  }

  async function handleDelete(id) {
    await supabase.from("products").delete().eq("id", id);
    setProducts(products.filter(p => p.id !== id));
  }

  return (
    <div style={{ maxWidth: 1000, margin: "0 auto", padding: 24 }}>
      <AdminProductForm onSubmit={handleAdd} />
      <AdminProductList
        products={products}
        onEdit={p => setEditProduct(p)}
        onDelete={handleDelete}
      />
      <EditProductModal
        open={!!editProduct}
        product={editProduct}
        onSave={handleEditSave}
        onClose={() => setEditProduct(null)}
      />
    </div>
  );
}
